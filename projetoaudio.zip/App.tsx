import { StatusBar } from "expo-status-bar";
import { Feather } from "@expo/vector-icons";
import { Buffer } from "buffer";
import {
  Pressable,
  StyleSheet,
  TextInput,
  View,
  Text,
  PermissionsAndroid,
} from "react-native";
import { useEffect, useRef, useState } from "react";
import { requestMicrophonePermission as requestVoicePermissions } from "./src/utils/permissions/voice";
import { io, Socket } from "socket.io-client";
import AudioRecord from "react-native-audio-record";

// LogBox.ignoreLogs(["new NativeEventEmitter"]);

export default function App() {
  const [isListening, setIsListening] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<Socket>();

  // Permiss천es
  useEffect(() => {
    async function checkPermissions() {
      const hasVoicePermissions = await requestVoicePermissions();
      if (!hasVoicePermissions) {
        alert("Voce n deu permissoes necessarias");
        return;
      }
    }

    checkPermissions();

    socketRef.current = io(`${'http://127.0.0.1:3000'}`, {
      query: { type: "sender" },
      transports: ["websocket"],
    });

    const socket = socketRef.current;

    socket.on("connect", () => {
      setIsConnected(true);
      console.log("WebSocket connected");
    });

    socket.on("connect_error", (error) => {
      console.error("Erro de conex찾o:", error.message);
    });

    socket.on("disconnect", () => {
      setIsConnected(false);
      console.log("WebSocket disconnected");
    });

    AudioRecord.on("data", (data) => {
      // base64-encoded audio data chunks
      let arrayByffer = Buffer.from(data, "base64");
      if (socketRef.current) {
        socketRef.current.emit("audio", arrayByffer);
      }
    });

    return () => {
      socket.off();
      socket.disconnect();
    };
  }, []);

  const onStartRecord = async () => {

    setIsListening(true);
    
    AudioRecord.init({
      sampleRate: 16000, // default 44100
      channels: 1, // 1 or 2, default 1
      bitsPerSample: 16, // 8 or 16, default 16
      audioSource: 6, // android only (see below)
      wavFile: "test.wav", // default 'audio.wav';
    })
    console.log("Start");

    // Precisa chamar permiss찾o
    const result = await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO
    );

    if (result) {
      AudioRecord.start();
    }
  };

  const onStopRecord = async () => {
    setIsListening(false);
    console.log("stop rec");
    const audioFile = await AudioRecord.stop();
    console.log(audioFile);
  };


  return (
    <View style={styles.container}>
      <StatusBar style="dark" backgroundColor="transparent" translucent />

      <View>
        <Text
          style={[styles.socketTitle, isConnected && styles.socketConnected]}
        >
          {isConnected ? "Conectado" : "Desconectado"}
        </Text>
      </View>

      <View style={styles.header}>
        <TextInput
          style={styles.input}
          value={isListening ? "Ouvindo..." : "Pressione o bot찾o para falar"}
        />

        <Pressable
          style={styles.button}
          onPress={onStartRecord}
        >
          <Feather
            name={"mic"}
            color="#FFF"
            size={24}
          />
        </Pressable>

        <Pressable
          style={styles.button}
          onPress={onStartRecord}
        >
          <Feather
            name={"pause"}
            color="#FFF"
            size={24}
          />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 32,
    paddingVertical: 52,
  },
  header: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  input: {
    flex: 1,
    height: 54,
    padding: 16,
    fontSize: 16,
    borderRadius: 12,
    backgroundColor: "#D9E6EB",
  },
  button: {
    height: 54,
    width: 54,
    borderRadius: 12,
    backgroundColor: "#6F4AE5",
    justifyContent: "center",
    alignItems: "center",
  },
  socketTitle: {
    fontSize: 18,
    fontWeight: "500",
    color: "red",
    textAlign: "center",
    margin: 16,
  },
  socketConnected: {
    color: "green",
  },
});